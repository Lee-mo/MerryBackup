import game_framework
import  stage1_state
from pico2d import *

name = "TitleState"
image = None

def enter():
    global menu
    menu = 1
    global menu_start, menu_exit
    menu_start = load_image('Menu_start.png')
    menu_exit = load_image('Menu_exit.png')

def exit():
    global menu_start, menu_exit
    del(menu_start)
    del(menu_exit)

def handle_events():
    events = get_events()
    global menu
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if event.type == SDL_KEYDOWN and (event.key == SDLK_DOWN or event.key == SDLK_UP):
                if menu == 1:
                    menu = 2
                elif menu == 2:
                    menu = 1
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RETURN):
                if menu == 1:
                    game_framework.push_state(stage1_state)
                elif menu == 2:
                    game_framework.quit()

def draw():
    global menu
    clear_canvas()
    if menu == 1:
        menu_start.draw(512,384)
    elif menu == 2:
        menu_exit.draw(512,384)
    update_canvas()

def update():
    pass

def pause():
    pass

def resume():
    pass
