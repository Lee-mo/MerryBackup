from pico2d import *

class Dog:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP = 1, 2, 3, 4, 5, 6
    def __init__(self):
        self.state = self.RIGHT_STAND
        self.x = 400
        self.y = 158
        self.frame=0
        self.jframe=0
        self.hp = 100
        self.RSimage = load_image('DogRstop.png')
        self.RWimage = load_image('DogRwalk.png')
        self.LSimage = load_image('DogLstop.png')
        self.LWimage = load_image('DogLwalk.png')
        self.RJimage = load_image('DogRjump.png')
        self.LJimage = load_image('DogLjump.png')
        self.size = 35
        self.jcount = 0 #jump count

    def Update(self):
        if self.state == self.RIGHT_WALK:
            self.frame = (self.frame + 1) % 6
        elif self.state == self.LEFT_WALK:
            self.frame = (self.frame - 1) % 6
        elif self.state == self.RIGHT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.RIGHT_WALK
        elif self.state == self.LEFT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.LEFT_STAND

    def Draw(self):
        if self.state == self.RIGHT_WALK:
            self.RWimage.clip_draw(self.frame * 88,0,88,54,400,158)
        elif self.state == self.LEFT_WALK:
            self.LWimage.clip_draw(self.frame * 88, 0, 88, 54, 400, 158)
        elif self.state==self.RIGHT_JUMP:
            self.RJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state==self.LEFT_JUMP:
            self.LJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state == self.RIGHT_STAND:
            self.RSimage.clip_draw(0,0,60,52,400,self.y)
        elif self.state== self.LEFT_STAND:
            self.LSimage.clip_draw(0, 0, 60, 52, 400, self.y)

    def handle_events(self, event):
        #<-
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):#push <-
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):#not push <-
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
        #->
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):#push ->
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):#not push ->
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
        #JUMP
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if self.state in (self.LEFT_STAND, self.LEFT_WALK):
                self.state = self.LEFT_JUMP
            elif self.state in (self.RIGHT_STAND, self.RIGHT_WALK):
                self.state = self.RIGHT_JUMP
