from pico2d import *

class Monster:
    class RedHorn:
        def __init__(self):
            self.x = 1000
            self.y = 160
            self.frame = 0
            self.scale = 10
            self.state=1 #Idle:1 move to left, 2 move to right
            self.moveCnt=0
            self.speed=4
            self.idleImage0 = load_image('RedHorn1.png')
            self.idleImage1 = load_image('RedHorn2.png')
            self.idleImage2 = load_image('RedHorn3.png')
            self.idleImage3 = load_image('RedHorn4.png')
            self.hitImage = load_image('RedHornHit.png')

        def Draw(self):
            if self.state==1:
                if self.frame == 0 :
                    self.idleImage0.draw(self.x,self.y,self.idleImage0.w/self.scale,self.idleImage0.h/self.scale)
                elif self.frame == 1:
                    self.idleImage1.draw(self.x, self.y,self.idleImage1.w/self.scale,self.idleImage1.h/self.scale)
            elif self.state==2:
                if self.frame == 0:
                    self.idleImage2.draw(self.x, self.y, self.idleImage0.w / self.scale, self.idleImage0.h / self.scale)
                elif self.frame == 1:
                    self.idleImage3.draw(self.x, self.y, self.idleImage1.w / self.scale, self.idleImage1.h / self.scale)

        def Update(self, dogState, dogDir):
            self.frame = (self.frame+1)%2
            #Monster location
            if dogState == 'W':
                if dogDir == 'R':
                    self.x -= 10
                elif dogDir == 'L':
                    self.x += 10
            elif dogState == 'J':
                if dogDir == 'R':
                    self.x -= 20
                elif dogDir == 'L':
                    self.x += 20

        def Move(self):
            if self.state==1:#Move to left
                self.x-=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=2
            elif self.state==2:#Move to right
                self.x+=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=1
