import random
import json
import os

from pico2d import *

import game_framework
import object
import background
import dog
import monster
import collision
import Food
import game_over_state
name = "MainState"

merry = None
back = None

def enter():
    global merry, back, redHorn1, chicken#, box1
    merry = dog.Dog()
    back = background.Background()
    redHorn1 = monster.RedHorn()
    chicken = Food.ChickenLeg()
    #box1 = object.MapObject.Box()
def exit():
    global merry, back, redHorn1, chicken #, box1
    del(merry)
    del(back)
    del(redHorn1)
    del(chicken)
    #del(box1)
def pause():
    pass

def resume():
    pass

def handle_events():
    global merry
    global box1
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            back.handle_events(event)
            merry.handle_events(event)
            redHorn1.handle_events(event)
            chicken.handle_events(event)

def update():
    merry.Update()
    redHorn1.Update()
    chicken.Update()

    redHorn1.Move()

    if collision.collide(merry, redHorn1) == True and merry.hp > 0:
        merry.hp -= 1
        if merry.hp == 0:
            merry.state = merry.DOWN
    if collision.collide(merry, chicken) == True and chicken.state != chicken.EATEN:
        chicken.state = chicken.EATEN
        if merry.hp < 5: merry.hp += 1
    back.Update(1)
    delay(0.06)

def draw():
    clear_canvas()
    back.Draw()
    redHorn1.Draw()
    chicken.Draw()
    merry.Draw()

    merry.ShowHp()

    merry.Draw_bb()
    redHorn1.Draw_bb()
    chicken.Draw_bb()
    #box1.Draw()
    font = load_font('ENCR10B.TTF', 25)
    font.draw(850, 730, 'STAGE 1', (200, 200, 200))

    if merry.hp == 0:
        game_framework.push_state(game_over_state)

    update_canvas()

