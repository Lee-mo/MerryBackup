import game_framework
import  title_state
from pico2d import *

name = "GameOverState"
image = None

def enter():
    pass

def exit():
    pass

def handle_events():
    events = get_events()

    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else: pass

def draw():

    update_canvas()

def update():
    pass

def pause():
    pass

def resume():
    pass
