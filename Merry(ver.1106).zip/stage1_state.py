import random
import json
import os

from pico2d import *

import game_framework
import object

name = "MainState"

merry = None
background = None

def enter():
    global merry, background, redHorn1#, box1
    merry = object.Dog()
    background = object.Background()
    redHorn1 = object.Monster.RedHorn()
    #box1 = object.MapObject.Box()
def exit():
    global merry, background, redHorn1#, box1
    del(merry)
    del(background)
    del(redHorn1)
    #del(box1)
def pause():
    pass

def resume():
    pass

def handle_events():
    global merry
    global box1
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            background.handle_events(event)
            merry.handle_events(event)

def update():
    merry.Update()
    #redHorn1.Update()
    redHorn1.Move()
    #box1.Update(merry.state, merry.dir)
    background.Update(1)
    delay(0.06)

def draw():
    clear_canvas()
    background.Draw()
    merry.Draw()
    redHorn1.Draw()
    #box1.Draw()
    update_canvas()

