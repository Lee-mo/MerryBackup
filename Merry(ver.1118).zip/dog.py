from pico2d import *

class Dog:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP, DOWN = 1, 2, 3, 4, 5, 6, 0
    def __init__(self):
        self.state = self.RIGHT_STAND
        self.x = 400
        self.y = 158
        self.frame=0
        self.jframe=0
        self.hp = 5
        self.leftKey, self.rightKey, self.upKey, self.downKey, self.spaceKey = 0, 0, 0, 0, 0
        self.RSimage = load_image('DogRstop.png')
        self.RWimage = load_image('DogRwalk.png')
        self.LSimage = load_image('DogLstop.png')
        self.LWimage = load_image('DogLwalk.png')
        self.RJimage = load_image('DogRjump.png')
        self.LJimage = load_image('DogLjump.png')
        self.heart = load_image('heart_4.png')
        self.DNimage = load_image('DogDown.png')
        self.size = 35
        self.jcount = 0 #jump count
        self.next = self.RIGHT_STAND

    def Update(self):
        if self.state == self.RIGHT_WALK:
            self.frame = (self.frame + 1) % 6
        elif self.state == self.LEFT_WALK:
            self.frame = (self.frame - 1) % 6
        elif self.state == self.RIGHT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.next
        elif self.state == self.LEFT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.next

    def Draw(self):
        if self.state == self.RIGHT_WALK:
            self.RWimage.clip_draw(self.frame * 88,0,88,54,400,158)
        elif self.state == self.LEFT_WALK:
            self.LWimage.clip_draw(self.frame * 88, 0, 88, 54, 400, 158)
        elif self.state==self.RIGHT_JUMP:
            self.RJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state==self.LEFT_JUMP:
            self.LJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state == self.RIGHT_STAND:
            self.RSimage.clip_draw(0,0,60,52,400,self.y)
        elif self.state == self.LEFT_STAND:
            self.LSimage.clip_draw(0, 0, 60, 52, 400, self.y)
        elif self.state == self.DOWN:
            self.DNimage.draw(400, self.y - 8)

    def handle_events(self, event):
        #<-
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT) and self.jcount == 0:#push <-
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
            self.leftKey = 1
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):#not push <-
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
            self.leftKey = 0
            if self.rightKey == 1:
                self.state = self.RIGHT_WALK
        #->
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT) and self.jcount == 0:#push ->
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
            self.rightKey = 1
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):#not push ->
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
            self.rightKey = 0
            if self.leftKey == 1:
                self.state = self.LEFT_WALK
        #JUMP
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if self.state in (self.LEFT_STAND, self.LEFT_WALK):
                self.state = self.LEFT_JUMP
            elif self.state in (self.RIGHT_STAND, self.RIGHT_WALK):
                self.state = self.RIGHT_JUMP
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_SPACE):
            if self.rightKey == 1: self.next = self.RIGHT_WALK
            elif self.leftKey == 1: self.next = self.LEFT_WALK
            elif self.state == self.RIGHT_JUMP: self.next = self.RIGHT_STAND
            elif self.state == self.LEFT_JUMP: self.next = self.LEFT_STAND

    def ShowHp(self):
        if self.hp >= 1: self.heart.draw(50,730)
        if self.hp >= 2: self.heart.draw(100,730)
        if self.hp >= 3: self.heart.draw(150,730)
        if self.hp >= 4: self.heart.draw(200,730)
        if self.hp >= 5: self.heart.draw(250,730)

    def Get_bb(self):
        if self.state == self.RIGHT_STAND or self.state == self.LEFT_STAND:
            return self.x - 30, self.y - 30, self.x + 30, self.y + 30
        elif self.state == self.RIGHT_WALK or self.state == self.LEFT_WALK:
            return self.x - 40, self.y - 30, self.x + 40, self.y + 30
        elif self.state == self.RIGHT_JUMP:
            if self.jframe == 0: return self.x - 30, self.y - 30, self.x - 15, self.y + 30
            elif self.jframe == 1: return self.x - 30, self.y - 12, self.x + 30, self.y + 30
            elif self.jframe == 2: return self.x , self.y - 30, self.x + 15, self.y + 30
        elif self.state == self.LEFT_JUMP:
            if self.jframe == 0: return self.x + 7, self.y - 30, self.x + 22, self.y + 30
            elif self.jframe == 1: return self.x - 30, self.y - 12, self.x + 30, self.y + 30
            elif self.jframe == 2: return self.x - 15, self.y - 30, self.x, self.y + 30
        else:
            return 0, 0, 0, 0

    def Draw_bb(self):
        draw_rectangle(*self.Get_bb())
