import game_framework
import  title_state
from pico2d import *

name = "GameOverState"
image = None

def enter():
    pass

def exit():
    pass

def handle_events():
    events = get_events()

    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RETURN):
            game_framework.change_state(title_state)

def draw():
    downMsg = load_image('게임오버안내.png')
    keyMsg = load_image('키입력안내.png')
    downMsg.draw(500,400)
    keyMsg.draw(500,500)
    update_canvas()

def update():
    pass

def pause():
    pass

def resume():
    pass
