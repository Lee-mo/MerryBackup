from pico2d import *

class Background:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK = 1,2,3,4

    def __init__(self):
        self.x=512
        self.y=768/2
        self.frame=0
        self.left=0
        self.speed=10
        self.screenW=1024
        self.screenH=768
        self.image = load_image('RedSky2.png')
        self.state = self.RIGHT_STAND

    def Draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screenW)
        self.image.clip_draw_to_origin(x,0,w,self.screenH,0,0)
        self.image.clip_draw_to_origin(0,0,self.screenW-w,self.screenH,w,0)

    def Update(self, frame_time):
        if self.state == self.LEFT_WALK:
            self.speed = -10
        elif self.state == self.RIGHT_WALK:
            self.speed = 10
        else:
            self.speed = 0
        self.left = (self.left + frame_time * self.speed) % self.image.w

    def handle_events(self, event):
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
#-----------------------------------------------------------------------------------------------------------------------
class Dog:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP = 1, 2, 3, 4, 5, 6
    def __init__(self):
        self.state = self.RIGHT_STAND
        self.x = 400
        self.y = 158
        self.frame=0
        self.jframe=0
        self.RSimage = load_image('DogRstop.png')
        self.RWimage = load_image('DogRwalk.png')
        self.LSimage = load_image('DogLstop.png')
        self.LWimage = load_image('DogLwalk.png')
        self.RJimage = load_image('DogRjump.png')
        self.LJimage = load_image('DogLjump.png')
        self.size = 35
        self.jcount = 0

    def Update(self):
        if self.state == self.RIGHT_WALK:
            self.frame = (self.frame + 1) % 6
        elif self.state == self.LEFT_WALK:
            self.frame = (self.frame - 1) % 6
        elif self.state == self.RIGHT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.RIGHT_STAND
        elif self.state == self.LEFT_JUMP:
            if self.jframe == 0:
                self.y += 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jframe = 1
                    self.jcount = 0
            elif self.jframe == 1:
                self.jcount += 1
                if self.jcount == 2:
                    self.jframe = 2
                    self.jcount = 0
            elif self.jframe == 2:
                self.y -= 10
                self.jcount += 1
                if self.jcount == 10:
                    self.jcount = 0
                    self.jframe = 0
                    self.state = self.LEFT_STAND

    def Draw(self):
        if self.state == self.RIGHT_WALK:
            self.RWimage.clip_draw(self.frame * 88,0,88,54,400,158)
        elif self.state == self.LEFT_WALK:
            self.LWimage.clip_draw(self.frame * 88, 0, 88, 54, 400, 158)
        elif self.state==self.RIGHT_JUMP:
            self.RJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state==self.LEFT_JUMP:
            self.LJimage.clip_draw(self.jframe*74,0,74,62,400,self.y)
        elif self.state == self.RIGHT_STAND:
            self.RSimage.clip_draw(0,0,60,52,400,self.y)
        elif self.state== self.LEFT_STAND:
            self.LSimage.clip_draw(0, 0, 60, 52, 400, self.y)

    def handle_events(self, event):
        #<-
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):#push <-
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):#not push <-
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
        #->
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):#push ->
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):#not push ->
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
        #JUMP
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if self.state in (self.LEFT_STAND, self.LEFT_WALK):
                self.state = self.LEFT_JUMP
            elif self.state in (self.RIGHT_STAND, self.RIGHT_WALK):
                self.state = self.RIGHT_JUMP

#-----------------------------------------------------------------------------------------------------------------------
class Monster:
    class RedHorn:
        def __init__(self):
            self.x = 1000
            self.y = 160
            self.frame = 0
            self.scale = 10
            self.state=1 #Idle:1 move to left, 2 move to right
            self.moveCnt=0
            self.speed=4
            self.idleImage0 = load_image('RedHorn1.png')
            self.idleImage1 = load_image('RedHorn2.png')
            self.idleImage2 = load_image('RedHorn3.png')
            self.idleImage3 = load_image('RedHorn4.png')
            self.hitImage = load_image('RedHornHit.png')

        def Draw(self):
            if self.state==1:
                if self.frame == 0 :
                    self.idleImage0.draw(self.x,self.y,self.idleImage0.w/self.scale,self.idleImage0.h/self.scale)
                elif self.frame == 1:
                    self.idleImage1.draw(self.x, self.y,self.idleImage1.w/self.scale,self.idleImage1.h/self.scale)
            elif self.state==2:
                if self.frame == 0:
                    self.idleImage2.draw(self.x, self.y, self.idleImage0.w / self.scale, self.idleImage0.h / self.scale)
                elif self.frame == 1:
                    self.idleImage3.draw(self.x, self.y, self.idleImage1.w / self.scale, self.idleImage1.h / self.scale)

        def Update(self, dogState, dogDir):
            self.frame = (self.frame+1)%2
            #Monster location
            if dogState == 'W':
                if dogDir == 'R':
                    self.x -= 10
                elif dogDir == 'L':
                    self.x += 10
            elif dogState == 'J':
                if dogDir == 'R':
                    self.x -= 20
                elif dogDir == 'L':
                    self.x += 20

        def Move(self):
            if self.state==1:#Move to left
                self.x-=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=2
            elif self.state==2:#Move to right
                self.x+=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=1


class MapObject:
    class Box:
        def __init__(self):
            self.x=0
            self.y=155
            self.image1 = load_image('obj_box001.png')
            self.image2 = load_image('obj_box002.png')
            self.image3 = load_image('obj_box003.png')
            self.image4 = load_image('obj_box004.png')
            self.image5 = load_image('obj_box005.png')
            self.speed = 10
            self.scale = 2
            self.type = 1

        def Draw(self):
            if self.type == 1:
                self.image1.draw(self.x,self.y,self.image1.w/self.scale, self.image1.h/self.scale)
            elif self.type == 2:
                self.image2.draw(self.x, self.y, self.image2.w / self.scale, self.image2.h / self.scale)
            elif self.type == 3:
                self.image3.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)
            elif self.type == 4:
                self.image4.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)
            elif self.type == 5:
                self.image5.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)

        def Update(self, dogState, dogDir):
            if dogState == 'W':
                if dogDir == 'R':
                    self.x -= 10
                elif dogDir == 'L':
                    self.x += 10
            elif dogState == 'J':
                if dogDir == 'R':
                    self.x -= 20
                elif dogDir == 'L':
                    self.x += 20

        def Collide(self, dogX, dogY, dogState, dogSize):
            if dogX >= (self.x - self.image1.w/self.scale/2) and dogX<= (self.x + self.image1.w/self.scale/2):
                if dogState == 'W':
                    if dogX > self.x: return 'R'
                    elif dogX < self.x: return 'L'
                else: return 'N'
            else: return 0


