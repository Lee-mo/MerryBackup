from pico2d import *

class Dog:
    step_sound = None
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP, DOWN = 1, 2, 3, 4, 5, 6, 0
    x = 400
    walk_image_width = 88
    walk_image_height = 54
    jump_image_width = 74
    jump_image_height = 62
    stand_image_width = 60
    stand_image_height = 52
    walk_frame_number = 6
    sound_wait_number = 7
    def __init__(self):
        self.state = self.RIGHT_STAND
        self.y = 158
        self.walk_frame = 0
        self.jump_frame = 0
        self.heart = 5
        self.left_key, self.right_key, self.up_key, self.down_key = False, False, False, False
        self.right_stand_image = load_image('DogRstop.png')
        self.right_walk_image = load_image('DogRwalk.png')
        self.left_stand_image = load_image('DogLstop.png')
        self.left_walk_image = load_image('DogLwalk.png')
        self.right_jump_image = load_image('DogRjump.png')
        self.left_jump_image = load_image('DogLjump.png')
        self.heart_image = load_image('heart_4.png')
        self.down_image = load_image('DogDown.png')
        self.jump_height_count = 0
        self.sound_wait_count = 0

        if Dog.step_sound == None:
            Dog.step_sound = load_wav('step_l.wav')
            Dog.step_sound.set_volume(100)

    def Update(self, back):
        if self.state == self.RIGHT_WALK:
            self.walk_frame = (self.walk_frame + 1) % self.walk_frame_number
            self.Walk_sound()
        elif self.state == self.LEFT_WALK:
            self.walk_frame = (self.walk_frame - 1) % self.walk_frame_number
            self.Walk_sound()
        elif self.state == self.RIGHT_JUMP:
            self.Right_jump(back)
        elif self.state == self.LEFT_JUMP:
            self.Left_jump(back)

    def Draw(self):
        if self.state == self.RIGHT_WALK:
            self.right_walk_image.clip_draw(self.walk_frame * self.walk_image_width, 0, self.walk_image_width, self.walk_image_height, self.x, self.y)
        elif self.state == self.LEFT_WALK:
            self.left_walk_image.clip_draw(self.walk_frame * self.walk_image_width, 0, self.walk_image_width, self.walk_image_height, self.x, self.y)
        elif self.state==self.RIGHT_JUMP:
            self.right_jump_image.clip_draw(self.jump_frame * self.jump_image_width, 0, self.jump_image_width, self.jump_image_height, self.x, self.y)
        elif self.state==self.LEFT_JUMP:
            self.left_jump_image.clip_draw(self.jump_frame * self.jump_image_width, 0, self.jump_image_width, self.jump_image_height, self.x, self.y)
        elif self.state == self.RIGHT_STAND:
            self.right_stand_image.clip_draw(0, 0, self.stand_image_width, self.stand_image_height, self.x, self.y)
        elif self.state == self.LEFT_STAND:
            self.left_stand_image.clip_draw(0, 0, self.stand_image_width, self.stand_image_height, self.x, self.y)
        elif self.state == self.DOWN:
            self.down_image.draw(self.x, self.y)

    def handle_events(self, event):
        #<-
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT) and self.jump_height_count == 0:#push <-
            self.left_key = True
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):#not push <-
            self.left_key = False
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
            if self.right_key == 1:
                self.state = self.RIGHT_WALK
        #->
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT) and self.jump_height_count == 0:#push ->
            self.right_key = True
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):#not push ->
            self.right_key = False
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
            if self.left_key == 1:
                self.state = self.LEFT_WALK
        #JUMP
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if self.state in (self.LEFT_STAND, self.LEFT_WALK):
                self.state = self.LEFT_JUMP
            elif self.state in (self.RIGHT_STAND, self.RIGHT_WALK):
                self.state = self.RIGHT_JUMP

        print(self.left_key, ",", self.right_key)

    def Show_heart(self):
        if self.heart >= 1: self.heart_image.draw(50, 730)
        if self.heart >= 2: self.heart_image.draw(100, 730)
        if self.heart >= 3: self.heart_image.draw(150, 730)
        if self.heart >= 4: self.heart_image.draw(200, 730)
        if self.heart >= 5: self.heart_image.draw(250, 730)

    def Get_bb(self):
        if self.state == self.RIGHT_STAND or self.state == self.LEFT_STAND:
            return self.x - 30, self.y - 30, self.x + 30, self.y + 30
        elif self.state == self.RIGHT_WALK or self.state == self.LEFT_WALK:
            return self.x - 40, self.y - 30, self.x + 40, self.y + 30
        elif self.state == self.RIGHT_JUMP:
            if self.jump_frame == 0: return self.x - 30, self.y - 30, self.x - 15, self.y + 30
            elif self.jump_frame == 1: return self.x - 30, self.y - 12, self.x + 30, self.y + 30
            elif self.jump_frame == 2: return self.x , self.y - 30, self.x + 15, self.y + 30
        elif self.state == self.LEFT_JUMP:
            if self.jump_frame == 0: return self.x + 7, self.y - 30, self.x + 22, self.y + 30
            elif self.jump_frame == 1: return self.x - 30, self.y - 12, self.x + 30, self.y + 30
            elif self.jump_frame == 2: return self.x - 15, self.y - 30, self.x, self.y + 30
        else:
            return 0, 0, 0, 0

    def Draw_bb(self):
        draw_rectangle(*self.Get_bb())

    def Walk_sound(self):
        if self.sound_wait_count % 7 == 0:
            self.step_sound.play()
        self.sound_wait_count += 1

    def Right_jump(self, back):
        if self.jump_frame == 0:
            self.y += 10
            self.jump_height_count += 1
            if self.jump_height_count == 10:
                self.jump_frame = 1
                self.jump_height_count = 0
        elif self.jump_frame == 1:
            self.jump_height_count += 1
            if self.jump_height_count == 2:
                self.jump_frame = 2
                self.jump_height_count = 0
        elif self.jump_frame == 2:
            self.y -= 10
            self.jump_height_count += 1
            if self.jump_height_count == 10:
                self.jump_height_count = 0
                self.jump_frame = 0
                if back.state == back.RIGHT_WALK:
                    self.state = self.RIGHT_WALK
                elif back.state == back.LEFT_WALK:
                    self.state = self.LEFT_WALK
                else:
                    self.state = self.RIGHT_STAND

    def Left_jump(self, back):
        if self.jump_frame == 0:
            self.y += 10
            self.jump_height_count += 1
            if self.jump_height_count == 10:
                self.jump_frame = 1
                self.jump_height_count = 0
        elif self.jump_frame == 1:
            self.jump_height_count += 1
            if self.jump_height_count == 2:
                self.jump_frame = 2
                self.jump_height_count = 0
        elif self.jump_frame == 2:
            self.y -= 10
            self.jump_height_count += 1
            if self.jump_height_count == 10:
                self.jump_height_count = 0
                self.jump_frame = 0
                if back.state == back.RIGHT_WALK:
                    self.state = self.RIGHT_WALK
                elif back.state == back.LEFT_WALK:
                    self.state = self.LEFT_WALK
                else:
                    self.state = self.LEFT_STAND