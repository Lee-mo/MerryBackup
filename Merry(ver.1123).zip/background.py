from pico2d import *

class Background:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK = 1,2,3,4

    def __init__(self):
        self.x=512
        self.y=768/2
        self.frame=0
        self.left=0
        self.speed=10
        self.screenW=1024
        self.screenH=768
        self.image = load_image('RedSky2.png')
        self.state = self.RIGHT_STAND
        self.lKey = 0
        self.rkey = 0
    def Draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screenW)
        self.image.clip_draw_to_origin(x,0,w,self.screenH,0,0)
        self.image.clip_draw_to_origin(0,0,self.screenW-w,self.screenH,w,0)

    def Update(self, frame_time):
        if self.state == self.LEFT_WALK:
            self.speed = -10
        elif self.state == self.RIGHT_WALK:
            self.speed = 10
        else:
            self.speed = 0
        self.left = (self.left + frame_time * self.speed) % self.image.w

    def handle_events(self, event):
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            self.lKey = 1
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            self.lKey = 0
            if self.state in (self.LEFT_WALK,):
                self.state = self.LEFT_STAND
            if self.rkey == 1: self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            self.rkey = 1
            if self.state in (self.LEFT_STAND, self.RIGHT_STAND):
                self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            self.rkey = 0
            if self.state in (self.RIGHT_WALK,):
                self.state = self.RIGHT_STAND
            if self.lKey == 1: self.state = self.LEFT_WALK