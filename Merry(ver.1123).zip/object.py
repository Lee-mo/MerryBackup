from pico2d import *

class MapObject:
    class Box:
        def __init__(self):
            self.x=0
            self.y=155
            self.image1 = load_image('obj_box001.png')
            self.image2 = load_image('obj_box002.png')
            self.image3 = load_image('obj_box003.png')
            self.image4 = load_image('obj_box004.png')
            self.image5 = load_image('obj_box005.png')
            self.speed = 10
            self.scale = 2
            self.type = 1

        def Draw(self):
            if self.type == 1:
                self.image1.draw(self.x,self.y,self.image1.w/self.scale, self.image1.h/self.scale)
            elif self.type == 2:
                self.image2.draw(self.x, self.y, self.image2.w / self.scale, self.image2.h / self.scale)
            elif self.type == 3:
                self.image3.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)
            elif self.type == 4:
                self.image4.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)
            elif self.type == 5:
                self.image5.draw(self.x, self.y, self.image1.w / self.scale, self.image1.h / self.scale)

        def Update(self, dogState, dogDir):
            if dogState == 'W':
                if dogDir == 'R':
                    self.x -= 10
                elif dogDir == 'L':
                    self.x += 10
            elif dogState == 'J':
                if dogDir == 'R':
                    self.x -= 20
                elif dogDir == 'L':
                    self.x += 20

        def Collide(self, dogX, dogY, dogState, dogSize):
            if dogX >= (self.x - self.image1.w/self.scale/2) and dogX<= (self.x + self.image1.w/self.scale/2):
                if dogState == 'W':
                    if dogX > self.x: return 'R'
                    elif dogX < self.x: return 'L'
                else: return 'N'
            else: return 0


