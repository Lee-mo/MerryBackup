import random
import json
import os

from pico2d import *

import game_framework
import object

name = "MainState"

merry = None
background = None

def enter():
    global merry, background, redHorn1, box1
    merry = object.Dog()
    background = object.Background()
    redHorn1 = object.Monster.RedHorn()
    box1 = object.MapObject.Box()
def exit():
    global merry, background, redHorn1, box1
    del(merry)
    del(background)
    del(redHorn1)
    del(box1)
def pause():
    pass

def resume():
    pass

def handle_events():
    global merry
    global box1
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT and merry.state != 'J':  # Right Walk
            merry.dir = 'R'
            merry.state = 'W'
        elif event.type == SDL_KEYUP and event.key == SDLK_RIGHT and merry.state != 'J':  # Right Stop
            merry.state = 'S'
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT and merry.state != 'J':  # Left Walk
            merry.dir = 'L'
            merry.state = 'W'
        elif event.type == SDL_KEYUP and event.key == SDLK_LEFT and merry.state != 'J':  # Left Stop
            merry.state = 'S'
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP and merry.state != 'J':  # Jump
            merry.state = 'J'
            if merry.dir == 'R':
                merry.jumpState = 0
            elif merry.dir == 'L':
                merry.jumpState = 2
    #박스 충돌체크
    if box1.Collide(merry.x, merry.y, merry.state, merry.size)=='L' and merry.dir == 'R': merry.state = 'S'
    elif box1.Collide(merry.x, merry.y, merry.state, merry.size)=='R' and merry.dir == 'L': merry.state = 'S'
    elif box1.Collide(merry.x, merry.y, merry.state, merry.size)=='N':
        merry.y = box1.y + 50
        merry.state = 'S'
    else:
        if merry.state!='J': merry.y = 158

def update():
    merry.Update()
    redHorn1.Update(merry.state, merry.dir)
    redHorn1.Move()
    box1.Update(merry.state, merry.dir)
    background.Update(0.5, merry.dir, merry.state)
    delay(0.06)

def draw():
    clear_canvas()
    background.Draw()
    merry.Draw()
    redHorn1.Draw()
    box1.Draw()
    update_canvas()

