from pico2d import *


class RedHorn:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP = 1, 2, 3, 4, 5, 6
    y = 160
    def __init__(self):
        self.x = 800
        self.frame = 0
        self.scale = 10
        self.moveState = 1
        self.state = self.RIGHT_STAND
        self.move_count=0
        self.moveSpeed = 4
        self.backSpeed = 10
        self.idleImage0 = load_image('RedHorn1.png')
        self.idleImage1 = load_image('RedHorn2.png')
        self.idleImage2 = load_image('RedHorn3.png')
        self.idleImage3 = load_image('RedHorn4.png')
        self.hitImage = load_image('RedHornHit.png')

    def Draw(self):
        if self.moveState==1:
            if self.frame == 0 :
                self.idleImage0.draw(self.x,self.y,self.idleImage0.w/self.scale,self.idleImage0.h/self.scale)
            elif self.frame == 1:
                self.idleImage1.draw(self.x, self.y,self.idleImage1.w/self.scale,self.idleImage1.h/self.scale)
        elif self.moveState==2:
            if self.frame == 0:
                self.idleImage2.draw(self.x, self.y, self.idleImage0.w / self.scale, self.idleImage0.h / self.scale)
            elif self.frame == 1:
                self.idleImage3.draw(self.x, self.y, self.idleImage1.w / self.scale, self.idleImage1.h / self.scale)

    def Move(self):
        if self.moveState==1:#Move to left
            self.x-=self.moveSpeed
            self.move_count+=1
            if self.move_count==20:
                self.move_count=0
                self.moveState=2
        elif self.moveState==2:#Move to right
            self.x+=self.moveSpeed
            self.move_count+=1
            if self.move_count==20:
                self.move_count=0
                self.moveState=1

        self.frame += 1
        self.frame = self.frame % 2

    def handle_events(self, event):
        # <-
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):  # push <-
            self.state = self.LEFT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            self.state = self.LEFT_STAND
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):  # push ->
            self.state = self.RIGHT_WALK
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):  # push ->
            self.state = self.RIGHT_STAND

    def Update(self, back):
        if back.state == back.RIGHT_WALK:
            self.x -= self.backSpeed
        elif back.state == back.LEFT_WALK:
            self.x += self.backSpeed

    def Get_bb(self):
        return self.x - 28, self.y - 30, self.x + 28, self.y + 30

    def Draw_bb(self):
        draw_rectangle(*self.Get_bb())
