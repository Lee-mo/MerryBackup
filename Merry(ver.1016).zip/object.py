from pico2d import *

class Background:
    def __init__(self):
        self.x=512
        self.y=768/2
        self.frame=0
        self.left=0
        self.speed=10
        self.screenW=1024
        self.screenH=768
        self.image = load_image('RedSky.jpg')
        self.step=0

    def Draw(self):
        #self.image.clip_draw(self.frame,0,1024,768,self.x,self.y)
        x = int(self.left)
        w = min(self.image.w - x, self.screenW)
        self.image.clip_draw_to_origin(x,0,w,self.screenH,0,0)
        self.image.clip_draw_to_origin(0,0,self.screenW-w,self.screenH,w,0)

    def Update(self, frame_time, dogDir, dogState):
        self.speed=0

        if dogState!='S':
            if dogDir=='R':
                self.speed=10
            elif dogDir=='L' and self.step>0:
                self.speed=-10
        if dogState=='J':
            self.speed = self.speed*2
        self.left = (self.left + frame_time * self.speed) % self.image.w

        if dogState!='S':
            self.step = self.step + self.speed/10
            print("걸음수:", self.step)


class Dog:
    def __init__(self):
        self.state = 'S'
        self.dir = 'R'
        self.x = 400
        self.y = 158
        self.frame=0
        self.jumpState=0
        self.RSimage = load_image('DogRstop.png')
        self.RWimage = load_image('DogRwalk.png')
        self.LSimage = load_image('DogLstop.png')
        self.LWimage = load_image('DogLwalk.png')
        self.RJimage = load_image('DogRjump.png')
        self.LJimage = load_image('DogLjump.png')

    def Update(self):
        if self.state=='W':
            if self.dir=='R':
                self.frame = (self.frame + 1) % 6
            elif self.dir=='L':
                self.frame = (self.frame - 1) % 6
        elif self.state=='J':
            if self.dir == 'R':
                if self.jumpState == 0:
                    self.y = self.y + 20
                    if self.y >= 250:
                        self.jumpState = 1
                elif self.jumpState == 1:
                    self.y = self.y - 20
                    if self.y <= 250:
                        self.jumpState = 2
                elif self.jumpState == 2:
                    self.y = self.y - 20
                    if self.y <= 158:
                        self.y = 158
                        self.jumpState = 0
                        self.state = 'S'
            elif self.dir == 'L':
                if self.jumpState == 2:
                    self.y = self.y + 20
                    if self.y >= 250:
                        self.jumpState = 1
                elif self.jumpState == 1:
                    self.y = self.y - 20
                    if self.y <= 250:
                        self.jumpState = 0
                elif self.jumpState == 0:
                    self.y = self.y - 20
                    if self.y <= 158:
                        self.y = 158
                        self.jumpState = 2
                        self.state = 'S'

    def Draw(self):
        if self.state == 'W':
            if self.dir == 'R':
                self.RWimage.clip_draw(self.frame*88,0,88,54,400,158)
            elif self.dir=='L':
                self.LWimage.clip_draw(self.frame * 88, 0, 88, 54, 400, 158)
        elif self.state == 'J':
            if self.dir=='R':
                self.RJimage.clip_draw(self.jumpState*74,0,74,62,400,self.y)
            if self.dir=='L':
                self.LJimage.clip_draw(self.jumpState*74,0,74,62,400,self.y)
        elif self.state== 'S':
            if self.dir=='R':
                self.RSimage.clip_draw(0,0,60,52,400,158)
            elif self.dir=='L':
                self.LSimage.clip_draw(0, 0, 60, 52, 400, 158)


class Monster:
    class RedHorn:
        def __init__(self):
            self.x = 1000
            self.y = 160
            self.frame = 0
            self.scale = 10
            self.state=1 #Idle:1 move to left, 2 move to right
            self.moveCnt=0
            self.speed=4
            self.idleImage0 = load_image('RedHorn1.png')
            self.idleImage1 = load_image('RedHorn2.png')
            self.idleImage2 = load_image('RedHorn3.png')
            self.idleImage3 = load_image('RedHorn4.png')
            self.hitImage = load_image('RedHornHit.png')

        def Draw(self):
            if self.state==1:
                if self.frame == 0 :
                    self.idleImage0.draw(self.x,self.y,self.idleImage0.w/self.scale,self.idleImage0.h/self.scale)
                elif self.frame == 1:
                    self.idleImage1.draw(self.x, self.y,self.idleImage1.w/self.scale,self.idleImage1.h/self.scale)
            elif self.state==2:
                if self.frame == 0:
                    self.idleImage2.draw(self.x, self.y, self.idleImage0.w / self.scale, self.idleImage0.h / self.scale)
                elif self.frame == 1:
                    self.idleImage3.draw(self.x, self.y, self.idleImage1.w / self.scale, self.idleImage1.h / self.scale)

        def Update(self, dogState, dogDir, BackStep):
            self.frame = (self.frame+1)%2
            if BackStep > 0: #Monster location
                if dogState == 'W':
                    if dogDir == 'R':
                        self.x -= 10
                    elif dogDir == 'L':
                        self.x += 10
                elif dogState == 'J':
                    if dogDir == 'R':
                        self.x -= 20
                    elif dogDir == 'L':
                        self.x += 20
        def Move(self):
            if self.state==1:#Move to left
                self.x-=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=2
            elif self.state==2:#Move to right
                self.x+=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=1
