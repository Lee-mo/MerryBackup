from pico2d import *

class ChickenLeg:
    LEFT_STAND, RIGHT_STAND, LEFT_WALK, RIGHT_WALK, LEFT_JUMP, RIGHT_JUMP, EATEN = 1, 2, 3, 4, 5, 6, 0

    def __init__(self):
        self.x = 1200
        self.y = 150
        self.state = self.RIGHT_STAND
        self.image = load_image('chicken_leg.png')

    def Draw(self):
        if self.state != self.EATEN:
            self.image.draw(self.x, self.y)

    def handle_events(self, event):
        if self.state != self.EATEN:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):  # push <-
                self.state = self.LEFT_WALK
            elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
                self.state = self.LEFT_STAND
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):  # push ->
                self.state = self.RIGHT_WALK
            elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):  # push ->
                self.state = self.RIGHT_STAND

    def Update(self, back):
        if back.state == back.RIGHT_WALK:
            self.x -= 10
        elif back.state == back.LEFT_WALK:
            self.x += 10

    def Get_bb(self):
        return self.x - self.image.w/2, self.y - self.image.h/2, self.x + self.image.w/2, self.y + self.image.h/2

    def Draw_bb(self):
        if self.state != self.EATEN:
            draw_rectangle(*self.Get_bb())